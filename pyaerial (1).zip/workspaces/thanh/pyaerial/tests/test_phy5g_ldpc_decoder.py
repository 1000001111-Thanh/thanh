# Copyright (c) 2022-2024, NVIDIA CORPORATION. All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
"""Test LdpcDecoder."""
# Ensure that all the test vectors are available in TEST_VECTOR_DIR.
import glob
import pytest
from pytest import TEST_VECTOR_DIR

import h5py as h5
import numpy as np

from aerial.phy5g.ldpc import LdpcDecoder
from aerial.phy5g.ldpc.util import get_num_info_nodes
from aerial.phy5g.ldpc.util import get_base_graph
from aerial.phy5g.ldpc.util import find_lifting_size

test_case_numbers = [7018, 7019, 7020, 7021, 7022, 7023, 7026, 7027, 7028, 7029, 7030, 7031, 7033,
                     7034, 7035, 7036, 7037, 7038, 7040, 7041, 7042, 7043, 7044, 7046, 7047, 7048,
                     7049, 7050, 7051, 7052, 7053, 7054, 7055, 7056, 7058, 7059, 7060, 7061, 7062,
                     7063, 7064, 7065, 7066, 7067, 7068, 7069, 7070, 7071, 7072, 7073, 7074, 7075,
                     7076, 7077, 7078, 7079, 7080, 7081, 7082, 7083, 7084, 7085, 7086, 7087, 7088,
                     7089, 7090, 7091, 7092, 7093, 7094, 7095, 7096, 7097, 7098, 7099, 7100, 7101,
                     7102, 7103, 7104, 7105, 7106, 7107, 7108, 7109, 7110, 7111, 7112, 7113, 7114,
                     7115, 7116, 7117, 7118, 7119, 7120, 7121, 7122, 7123, 7124, 7125, 7126, 7127,
                     7128, 7129, 7130, 7131, 7132, 7133, 7134, 7135, 7136, 7137, 7138, 7139, 7140,
                     7141, 7142, 7143, 7144, 7145, 7146, 7147, 7148, 7149, 7150, 7151, 7152, 7153,
                     7201, 7202, 7203, 7204, 7205, 7206, 7207, 7208, 7209, 7210, 7211, 7212, 7213,
                     7214, 7215, 7216, 7217, 7218, 7219, 7220, 7221, 7222, 7223, 7225, 7227, 7229,
                     7230, 7231, 7232, 7233, 7236, 7242, 7249, 7251, 7252, 7253, 7254, 7255, 7256,
                     7258, 7259, 7261, 7301, 7302, 7303, 7304, 7305, 7306, 7346, 7347]


@pytest.mark.parametrize(
    "test_case_number",
    test_case_numbers,
    ids=[f"{test_case_number}" for test_case_number in test_case_numbers]
)
def test_ldpc_decoder(pusch_config, cuda_stream, test_case_number):
    """Test LDPC decoder."""
    filename = glob.glob(TEST_VECTOR_DIR + f"TVnr_{test_case_number}_PUSCH_gNB_CUPHY_s*.h5")[0]
    try:
        input_file = h5.File(filename, "r")
    except FileNotFoundError:
        pytest.skip("Test vector file not available, skipping...")
        return

    pusch_configs = pusch_config(input_file)

    tb_pars = np.array(input_file["tb_pars"])
    num_ues = len(tb_pars)

    input_llrs = []
    for ue_idx in range(num_ues):
        num_code_blocks = tb_pars["nCb"][ue_idx]
        input_llr = np.array(input_file[f"reference_rmOutLLRs{ue_idx}"])
        input_llr = input_llr.reshape(num_code_blocks, -1).T
        input_llrs.append(input_llr)

    ldpc_decoder = LdpcDecoder(cuda_stream=cuda_stream)
    decoded_bits = ldpc_decoder.decode(
        input_llrs=input_llrs,
        pusch_configs=pusch_configs
    )

    for ue_idx in range(num_ues):
        ref_code_blocks = np.transpose(np.array(input_file[f"reference_TbCbs_est{ue_idx}"]))
        assert np.array_equal(decoded_bits[ue_idx].astype(np.uint8), ref_code_blocks)


def test_ldpc_decoder_tput(cuda_stream):
    """Test LDPC decoder throughput."""
    test_vector_filename = "TVnr_7031_PUSCH_gNB_CUPHY_s0p0.h5"
    filename = TEST_VECTOR_DIR + test_vector_filename
    try:
        input_file = h5.File(filename, "r")
    except FileNotFoundError:
        pytest.skip("Test vector file not available, skipping...")
        return

    reference_tb_pars = input_file["tb_pars"]
    ldpc_decoder_tb_pars = np.array(reference_tb_pars)
    rv = ldpc_decoder_tb_pars["rv"][0]
    tbs = 8 * ldpc_decoder_tb_pars["nTbByte"][0]
    mod_order = ldpc_decoder_tb_pars["qamModOrder"][0]
    code_rate = ldpc_decoder_tb_pars["targetCodeRate"][0] / 10240.

    reference_tb_cbs_est = input_file["reference_TbCbs_est"]
    ldpc_decoder_ref_cbs = np.transpose(np.array(reference_tb_cbs_est))

    reference_eq_out_llr_s0 = input_file["reference_eqOutLLRs0"]
    ldpc_derate_match_input = np.array(reference_eq_out_llr_s0)
    rate_match_len = np.prod(ldpc_derate_match_input[..., :mod_order].shape)

    reference_rm_out_llr_s0 = input_file["reference_rmOutLLRs0"]
    ldpc_decoder_input_llr = np.transpose(np.array(reference_rm_out_llr_s0))

    ldpc_decoder = LdpcDecoder(
        throughput_mode=True,
        cuda_stream=cuda_stream
    )

    decoded_bits = ldpc_decoder.decode(
        input_llrs=[ldpc_decoder_input_llr],
        tb_sizes=[tbs],
        code_rates=[code_rate],
        redundancy_versions=[rv],
        rate_match_lengths=[rate_match_len]
    )[0]

    assert np.array_equal(decoded_bits, ldpc_decoder_ref_cbs)


@pytest.mark.parametrize(
    "test_case_number",
    test_case_numbers,
    ids=[f"{test_case_number}" for test_case_number in test_case_numbers]
)
def test_ldpc_decoder_soft_output(cuda_stream, test_case_number):
    """Test LDPC decoder soft outputs."""
    # Setting the number of iterations to zero means that the inputs come
    # out directly, except clamped to 32. Check this.
    filename = glob.glob(TEST_VECTOR_DIR + f"TVnr_{test_case_number}_PUSCH_gNB_CUPHY_s*.h5")[0]
    try:
        input_file = h5.File(filename, "r")
    except FileNotFoundError:
        pytest.skip("Test vector file not available, skipping...")
        return

    tb_pars = np.array(input_file["tb_pars"])
    rv = tb_pars["rv"][0]
    tbs = 8 * tb_pars["nTbByte"][0]
    mod_order = tb_pars["qamModOrder"][0]
    code_rate = tb_pars["targetCodeRate"][0] / 10240.
    num_code_blocks = tb_pars["nCb"][0]

    ldpc_derate_match_input = np.array(input_file["reference_eqOutLLRs0"])
    rate_match_len = np.prod(ldpc_derate_match_input[..., :mod_order].shape)
    ldpc_decoder_input_llr = np.transpose(np.array(input_file["reference_rmOutLLRs0"]))

    ldpc_decoder = LdpcDecoder(cuda_stream=cuda_stream)
    ldpc_decoder.set_num_iterations(0)

    # Run the decoder.
    _ = ldpc_decoder.decode(
        input_llrs=[ldpc_decoder_input_llr],
        tb_sizes=[tbs],
        code_rates=[code_rate],
        redundancy_versions=[rv],
        rate_match_lengths=[rate_match_len]
    )
    bg = get_base_graph(tbs, code_rate)
    Zc = find_lifting_size(bg, tbs)
    Kb = get_num_info_nodes(bg, tbs)
    num_soft_bits = (Kb * Zc + 1) // 2 * 2

    # Get the soft output bits.
    soft_bits = ldpc_decoder.get_soft_bits()
    ldpc_decoder_input_llr = ldpc_decoder_input_llr.reshape(num_code_blocks, -1).T
    assert np.allclose(np.clip(ldpc_decoder_input_llr[:num_soft_bits, :], -32, 32),
                       soft_bits[0])
